<?php

declare(strict_types=1);

namespace App\Models;

use Agus\Database\Model;
use Agus\Database\QueryBuilder;

class Listing extends Model
{
    protected static string $table = 'listings';

    protected static array $fillable = [
        'shop_id', 'name', 'description', 'category', 'original_price', 'price',
        'quantity', 'allergens', 'photo', 'best_before', 'pickup_window',
    ];

    public const CATEGORIES = [
        'bread' => ['label' => 'Bread & pastries', 'icon' => '🥐'],
        'meals' => ['label' => 'Meals', 'icon' => '🍱'],
        'desserts' => ['label' => 'Desserts', 'icon' => '🍰'],
        'drinks' => ['label' => 'Drinks', 'icon' => '🧋'],
    ];

    /**
     * Listings customers can see: from a verified shop, still in stock,
     * and not past their best-before date. Shop details come along via a join.
     */
    public static function available(): QueryBuilder
    {
        return static::query()
            ->select(
                'listings.*',
                'shops.name AS shop_name',
                'shops.address AS shop_address',
                'shops.latitude AS shop_latitude',
                'shops.longitude AS shop_longitude'
            )
            ->join('shops', 'shops.id', '=', 'listings.shop_id')
            ->where('shops.is_verified', 1)
            ->where('listings.quantity', '>', 0)
            ->where('listings.best_before', '>=', date('Y-m-d'));
    }

    public static function findAvailable(int $id): ?self
    {
        return static::available()->where('listings.id', $id)->first();
    }

    public function shop(): ?Shop
    {
        return $this->belongsTo(Shop::class, 'shop_id');
    }

    public function categoryLabel(): string
    {
        return self::CATEGORIES[$this->category]['label'] ?? ucfirst((string) $this->category);
    }

    public function icon(): string
    {
        return self::CATEGORIES[$this->category]['icon'] ?? '🍽️';
    }

    /** Percent off the original price, e.g. 50. */
    public function discount(): int
    {
        $original = (float) $this->original_price;
        return $original > 0 ? (int) round((1 - (float) $this->price / $original) * 100) : 0;
    }

    /** Kilometres from a point, using the shop's map pin (null if the shop has no pin). */
    public function distanceFrom(float $lat, float $lon): ?float
    {
        $shopLat = $this->shop_latitude ?? null;
        $shopLon = $this->shop_longitude ?? null;
        if ($shopLat === null || $shopLon === null) {
            return null;
        }
        return self::haversine($lat, $lon, (float) $shopLat, (float) $shopLon);
    }

    /** Great-circle distance between two coordinates, in kilometres. */
    public static function haversine(float $lat1, float $lon1, float $lat2, float $lon2): float
    {
        $r = 6371.0;
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);
        $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon / 2) ** 2;
        return $r * 2 * atan2(sqrt($a), sqrt(1 - $a));
    }
}
