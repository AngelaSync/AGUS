<?php /** @var \Agus\View\View $this */ $this->layout('layouts/main', ['title' => $title]);
$pinForm = function ($shop): string {
    return '<form method="post" action="' . e(route('admin.shops.location', ['id' => $shop->id])) . '" class="pin-form">' . csrf_field()
        . '<input name="latitude" inputmode="decimal" placeholder="Latitude" value="' . e((string) $shop->latitude) . '" aria-label="Latitude">'
        . '<input name="longitude" inputmode="decimal" placeholder="Longitude" value="' . e((string) $shop->longitude) . '" aria-label="Longitude">'
        . '<button class="button ghost small" type="submit">Save pin</button></form>';
};
?>
<div class="page-head">
    <div>
        <p class="eyebrow">Admin</p>
        <h1>Replate at a glance</h1>
    </div>
</div>

<div class="stat-row">
    <div class="stat-card"><strong><?= (int) $stats['users'] ?></strong><span>accounts</span></div>
    <div class="stat-card"><strong><?= (int) $stats['shops'] ?></strong><span>shops</span></div>
    <div class="stat-card"><strong><?= (int) $stats['listings'] ?></strong><span>live listings</span></div>
    <div class="stat-card"><strong><?= (int) $stats['rescued'] ?></strong><span>items rescued</span></div>
</div>

<section class="section">
    <h2>Waiting for verification</h2>
    <?php if (!$pending): ?>
        <div class="empty"><div class="big">🎉</div><p class="muted">No shops waiting. All caught up!</p></div>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Shop</th><th>Map pin</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($pending as $shop): ?>
                    <tr>
                        <td><strong><?= e($shop->name) ?></strong><br><span class="muted"><?= e($shop->address) ?></span></td>
                        <td><?= $pinForm($shop) ?><?= $shop->hasPin() ? '' : '<p class="hint">Not found on the map. Place the pin by hand.</p>' ?></td>
                        <td>
                            <form method="post" action="<?= e(route('admin.shops.verify', ['id' => $shop->id])) ?>" class="inline">
                                <?= csrf_field() ?>
                                <button class="button green small" type="submit">Verify shop</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
    <?php endif ?>
</section>

<section class="section">
    <h2>Verified shops</h2>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Shop</th><th>Map pin</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($verified as $shop): ?>
                <tr>
                    <td><strong><?= e($shop->name) ?></strong> <span class="badge verified">verified</span><br><span class="muted"><?= e($shop->address) ?></span></td>
                    <td><?= $pinForm($shop) ?></td>
                    <td>
                        <form method="post" action="<?= e(route('admin.shops.verify', ['id' => $shop->id])) ?>" class="inline">
                            <?= csrf_field() ?>
                            <button class="button danger small" type="submit">Hide</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach ?>
            </tbody>
        </table>
    </div>
</section>

<section class="section">
    <h2>Accounts</h2>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead>
            <tbody>
            <?php foreach ($users['data'] as $u): ?>
                <tr>
                    <td><?= e($u->name) ?></td>
                    <td><?= e($u->email) ?></td>
                    <td><span class="badge"><?= e($u->role) ?></span></td>
                    <td><?= e(date('M j, Y', strtotime((string) $u->created_at))) ?></td>
                </tr>
            <?php endforeach ?>
            </tbody>
        </table>
    </div>
    <?php if ($users['last_page'] > 1): ?>
        <nav class="pager" aria-label="Pages">
            <?php for ($p = 1; $p <= $users['last_page']; $p++): ?>
                <a class="<?= $p === $users['current_page'] ? 'is-active' : '' ?>" href="?page=<?= $p ?>"><?= $p ?></a>
            <?php endfor ?>
        </nav>
    <?php endif ?>
</section>
