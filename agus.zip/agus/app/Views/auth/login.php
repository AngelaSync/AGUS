<?php /** @var \Agus\View\View $this */ $this->layout('layouts/main', ['title' => $title]) ?>

<div class="form-card">
    <h1>Sign in</h1>
    <form method="post" action="<?= e(url('/login')) ?>" novalidate>
        <?= csrf_field() ?>

        <label for="email">Email</label>
        <input id="email" name="email" type="email" autocomplete="email" value="<?= e(old('email')) ?>" required>
        <?php if ($err = errors('email')): ?><p class="field-error"><?= e($err) ?></p><?php endif ?>

        <label for="password">Password</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required>
        <?php if ($err = errors('password')): ?><p class="field-error"><?= e($err) ?></p><?php endif ?>

        <button class="button" type="submit">Sign in</button>
    </form>
    <p class="muted">No account yet? <a href="<?= e(route('register')) ?>">Create one</a></p>
    <?php if (config('app.debug')): ?>
        <div class="demo-accounts">
            <strong>Demo accounts</strong> (password <code>password123</code>)<br>
            Customer <code>juan@example.com</code> · Shop <code>rosa@example.com</code> · Admin <code>admin@example.com</code>
        </div>
    <?php endif ?>
</div>
