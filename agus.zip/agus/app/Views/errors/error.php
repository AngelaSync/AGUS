<?php /** @var \Agus\View\View $this */ $this->layout('layouts/main', ['title' => 'Error ' . $status]) ?>

<section class="error-page">
    <p class="error-code"><?= (int) $status ?></p>
    <h1><?= e($message) ?></h1>
    <p><a class="button" href="<?= e(url('/')) ?>">Back to home</a></p>

    <?php if (!empty($exception)): ?>
        <details class="debug" open>
            <summary><?= e($exception::class) ?> in <?= e(basename($exception->getFile())) ?>:<?= (int) $exception->getLine() ?></summary>
            <pre><?= e($exception->getTraceAsString()) ?></pre>
            <p class="muted">You see this because APP_DEBUG=true. Turn it off on a live server.</p>
        </details>
    <?php endif ?>
</section>
