<?php /** @var \Agus\View\View $this */ $this->layout('layouts/main', ['title' => $title]) ?>

<div class="panel">
    <p class="eyebrow">How it works</p>
    <h1>Replate, built on AGUS</h1>
    <p class="lead">Replate is a web app where bakeries and carinderias in Angeles City sell their leftover food at a discount. It runs on AGUS, a PHP MVC framework I wrote from scratch: no Laravel and no Composer packages.</p>

    <h2>For customers</h2>
    <ol class="flow">
        <li>Browse tonight's food, then search and filter by food type, price and distance.</li>
        <li>Reserve it and get a pickup code like <code>RP-7K4Q</code>.</li>
        <li>Go to the shop, check the food, show the code and pay at the counter.</li>
    </ol>

    <h2>How a request flows in AGUS</h2>
    <ol class="flow">
        <li><code>public/index.php</code> receives every request</li>
        <li><code>Request::capture()</code> wraps the URL, form data and headers</li>
        <li>Global middleware runs: logging, security headers, session, CSRF</li>
        <li>The <code>Router</code> finds the matching route</li>
        <li>Route middleware runs: <code>auth</code>, <code>role:shop</code>, <code>role:admin</code>, <code>throttle:5,1</code></li>
        <li>The controller action returns a <code>Response</code></li>
        <li><code>Response::send()</code> outputs the status, headers and body</li>
    </ol>
</div>
