<?php /** @var \Agus\View\View $this */ $role = auth()['role'] ?? null; ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <title><?= e(($title ?? '') !== '' ? $title . ' · Replate' : 'Replate') ?></title>
    <link rel="icon" href="<?= e(asset('img/replate-logo.png')) ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@600;700;800&family=Quicksand:wght@500;600;700&display=swap">
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
    <?= $this->section('head') ?>
</head>
<body>
<header class="site-header">
    <div class="container nav">
        <a class="brand" href="<?= e(url('/')) ?>"><img src="<?= e(asset('img/replate-logo.png')) ?>" alt="Replate: Don't waste it. Replate it." width="90" height="54"></a>
        <nav aria-label="Main" class="tabs">
            <?php $tab = fn (string $icon, string $full, string $short) => '<span class="tab-ic" aria-hidden="true">' . $icon . '</span><span class="full">' . e($full) . '</span><span class="short">' . e($short) . '</span>'; ?>
            <a class="<?= is_active('/', 'is-active') ?>" href="<?= e(route('home')) ?>"><?= $tab('🍽️', 'Browse food', 'Browse') ?></a>
            <a class="<?= is_active('/map', 'is-active') ?>" href="<?= e(route('map')) ?>"><?= $tab('🗺️', 'Map', 'Map') ?></a>
            <?php if ($role === 'customer'): ?>
                <a class="<?= is_active('/reservations', 'is-active') ?>" href="<?= e(route('reservations.index')) ?>"><?= $tab('🧾', 'My reservations', 'Orders') ?></a>
                <a class="<?= is_active('/sell', 'is-active') ?>" href="<?= e(route('shop.apply')) ?>"><?= $tab('🏪', 'Sell food', 'Sell') ?></a>
            <?php elseif ($role === 'shop'): ?>
                <a class="<?= is_active('/shop', 'is-active') ?>" href="<?= e(route('shop.home')) ?>"><?= $tab('🏪', 'My shop', 'My shop') ?></a>
            <?php elseif ($role === 'admin'): ?>
                <a class="<?= is_active('/admin', 'is-active') ?>" href="<?= e(route('admin.home')) ?>"><?= $tab('🛡️', 'Admin', 'Admin') ?></a>
            <?php endif ?>
            <?php if ($role): ?>
                <form method="post" action="<?= e(route('logout')) ?>" class="inline">
                    <?= csrf_field() ?>
                    <button class="link-button" type="submit"><?= $tab('👋', 'Sign out', 'Sign out') ?></button>
                </form>
            <?php else: ?>
                <a class="<?= is_active('/login', 'is-active') ?>" href="<?= e(route('login')) ?>"><?= $tab('🔑', 'Sign in', 'Sign in') ?></a>
                <a class="button small join <?= is_active('/register', 'is-active') ?>" href="<?= e(route('register')) ?>"><?= $tab('✨', 'Create account', 'Join') ?></a>
            <?php endif ?>
        </nav>
    </div>
</header>

<main class="container">
    <?= $this->insert('partials/flash') ?>
    <?= $this->section('content') ?>
</main>

<footer class="container footer">
    <span>Replate · Don't waste it. Replate it.</span>
    <span>Built on AGUS, my own PHP framework · <a href="<?= e(route('about')) ?>">How it works</a></span>
</footer>
<?= $this->section('scripts') ?>
</body>
</html>
