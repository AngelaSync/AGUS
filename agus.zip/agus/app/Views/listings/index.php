<?php /** @var \Agus\View\View $this */ $this->layout('layouts/main', ['title' => $title]);
use App\Models\Listing;
$queryWith = function (array $change) use ($filters): string {
    $params = array_filter(array_merge($filters, $change), fn ($v) => $v !== '' && $v !== null);
    return url('/') . ($params ? '?' . http_build_query($params) : '');
};
$totalLeft = array_sum(array_map(fn ($l) => (int) $l->quantity, $listings));
?>

<section class="hero">
    <div>
        <p class="eyebrow">Angeles City · tonight's surplus</p>
        <h1>Good food shouldn't go to waste. <span>Rescue it for less.</span></h1>
        <p class="lead">Bakeries and carinderias post what they couldn't sell. Reserve it here, check it at the shop, and pay at the counter.</p>
        <div class="stats">
            <div class="stat"><strong><?= count($listings) ?></strong><span>listings right now</span></div>
            <div class="stat"><strong><?= $totalLeft ?></strong><span>items left to rescue</span></div>
        </div>
    </div>
    <div class="hero-art" aria-hidden="true">
        <div class="plate"></div>
        <span class="food f1">🥐</span><span class="food f2">🍱</span><span class="food f3">🍰</span>
        <span class="dot" style="width:26px;height:26px;background:#FFB323;right:8%;top:6%"></span>
        <span class="dot" style="width:16px;height:16px;background:#DE4525;left:8%;top:14%"></span>
    </div>
</section>

<form class="filters" method="get" action="<?= e(url('/')) ?>" id="filters">
    <div class="search">
        <label for="q">Search</label>
        <input id="q" name="q" type="search" placeholder="Pandesal, adobo, ube…" value="<?= e($filters['q']) ?>">
    </div>
    <div>
        <label for="category">Food type</label>
        <select id="category" name="category">
            <option value="">All food</option>
            <?php foreach (Listing::CATEGORIES as $key => $cat): ?>
                <option value="<?= e($key) ?>" <?= $filters['category'] === $key ? 'selected' : '' ?>><?= e($cat['label']) ?></option>
            <?php endforeach ?>
        </select>
    </div>
    <div>
        <label for="max_price">Max price</label>
        <select id="max_price" name="max_price">
            <option value="">Any price</option>
            <?php foreach ([50, 100, 150, 250] as $p): ?>
                <option value="<?= $p ?>" <?= $filters['max_price'] === (string) $p ? 'selected' : '' ?>>Up to <?= e(money($p, 0)) ?></option>
            <?php endforeach ?>
        </select>
    </div>
    <div>
        <label for="radius">Distance</label>
        <select id="radius" name="radius">
            <option value="">Any distance</option>
            <?php foreach ([1, 2, 5, 10] as $km): ?>
                <option value="<?= $km ?>" <?= $filters['radius'] === (string) $km ? 'selected' : '' ?>>Within <?= $km ?> km</option>
            <?php endforeach ?>
        </select>
    </div>
    <div>
        <label for="sort">Sort by</label>
        <select id="sort" name="sort">
            <option value="nearest" <?= $filters['sort'] === 'nearest' ? 'selected' : '' ?>>Nearest</option>
            <option value="cheapest" <?= $filters['sort'] === 'cheapest' ? 'selected' : '' ?>>Cheapest</option>
            <option value="newest" <?= $filters['sort'] === 'newest' ? 'selected' : '' ?>>Newest</option>
        </select>
    </div>
    <input type="hidden" name="lat" id="lat" value="<?= e($filters['lat']) ?>">
    <input type="hidden" name="lon" id="lon" value="<?= e($filters['lon']) ?>">
    <div class="submit"><button class="button" type="submit">Search</button></div>
</form>

<div class="chips" aria-label="Quick filters">
    <a class="chip <?= $filters['category'] === '' ? 'is-active' : '' ?>" href="<?= e($queryWith(['category' => ''])) ?>">🍽️ All</a>
    <?php foreach (Listing::CATEGORIES as $key => $cat): ?>
        <a class="chip <?= $filters['category'] === $key ? 'is-active' : '' ?>" href="<?= e($queryWith(['category' => $key])) ?>"><?= $cat['icon'] ?> <?= e($cat['label']) ?></a>
    <?php endforeach ?>
</div>

<p class="location-note">
    📍 <?= $usingMyLocation ? 'Distances are from your location.' : 'Distances are from Angeles City center.' ?>
    <button class="button ghost small" type="button" id="use-location"><?= $usingMyLocation ? 'Update my location' : 'Use my location' ?></button>
</p>

<?php if (!$listings): ?>
    <div class="empty">
        <div class="big">🧺</div>
        <h2>Nothing matches yet</h2>
        <p class="muted">Try another food type, a higher price, or a wider distance. Shops post new food every evening.</p>
        <a class="button" href="<?= e(url('/')) ?>">Show all food</a>
    </div>
<?php else: ?>
    <div class="grid">
        <?php foreach ($listings as $listing): ?>
            <a class="card" href="<?= e(route('listings.show', ['id' => $listing->id])) ?>">
                <div class="photo">
                    <?= $this->insert('partials/listing-photo', ['listing' => $listing]) ?>
                    <?php if ($listing->discount() > 0): ?><span class="badge-off">-<?= $listing->discount() ?>%</span><?php endif ?>
                    <span class="badge-left <?= (int) $listing->quantity <= 3 ? 'low' : '' ?>"><?= (int) $listing->quantity ?> left</span>
                </div>
                <div class="body">
                    <h3><?= e($listing->name) ?></h3>
                    <div class="shop">
                        <span><?= e($listing->shop_name) ?></span>
                        <?php if ($listing->distance !== null): ?><span><?= $listing->distance < 0.1 ? 'Nearby' : e(number_format($listing->distance, 1)) . ' km' ?></span><?php endif ?>
                    </div>
                    <div class="pickup">🕖 Pickup <?= e($listing->pickup_window) ?></div>
                    <div class="price"><strong><?= e(money($listing->price)) ?></strong><s><?= e(money($listing->original_price)) ?></s></div>
                </div>
            </a>
        <?php endforeach ?>
    </div>
<?php endif ?>

<?php $this->start('scripts') ?>
<script>
document.getElementById('use-location').addEventListener('click', function () {
    var btn = this;
    if (!navigator.geolocation) { alert('Your browser can\'t share a location.'); return; }
    btn.textContent = 'Finding you…';
    navigator.geolocation.getCurrentPosition(function (pos) {
        document.getElementById('lat').value = pos.coords.latitude.toFixed(5);
        document.getElementById('lon').value = pos.coords.longitude.toFixed(5);
        document.getElementById('sort').value = 'nearest';
        document.getElementById('filters').submit();
    }, function () { btn.textContent = 'Location blocked'; });
});
</script>
<?php $this->end() ?>
