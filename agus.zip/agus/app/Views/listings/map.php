<?php /** @var \Agus\View\View $this */ $this->layout('layouts/main', ['title' => $title]) ?>

<div class="page-head">
    <div>
        <p class="eyebrow">Verified shops</p>
        <h1>Shops near you</h1>
        <p class="lead" style="margin:0">Each pin comes from the shop's address, turned into coordinates by the OpenStreetMap geocoding API.</p>
    </div>
    <a class="button ghost" href="<?= e(url('/')) ?>">Browse food</a>
</div>

<?php if (!$pins): ?>
    <div class="empty"><div class="big">🗺️</div><h2>No shops on the map yet</h2><p class="muted">Once an admin verifies a shop, it shows up here.</p></div>
<?php else: ?>
    <div class="big-map" id="map"></div>
<?php endif ?>

<?php if ($pins): ?>
<?php $this->start('scripts') ?>
<?= $this->insert('partials/leaflet') ?>
<script>
    var pins = <?= json_encode($pins, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    var map = L.map('map');
    replateTiles(map);
    var bounds = [];
    pins.forEach(function (p) {
        var esc = function (s) { var d = document.createElement('div'); d.textContent = s; return d.innerHTML; };
        var html = '<strong>' + esc(p.name) + '</strong><br>' + esc(p.address) + '<br>'
            + (p.listings > 0 ? '<a href="' + p.url + '">' + p.listings + ' listing' + (p.listings === 1 ? '' : 's') + ' tonight →</a>' : '<span>No food posted right now</span>');
        L.marker([p.lat, p.lon], { icon: replatePin('🍽️') }).addTo(map).bindPopup(html);
        bounds.push([p.lat, p.lon]);
    });
    if (bounds.length === 1) { map.setView(bounds[0], 15); } else { map.fitBounds(bounds, { padding: [40, 40] }); }
</script>
<?php $this->end() ?>
<?php endif ?>
