<?php /** @var \Agus\View\View $this */ $this->layout('layouts/main', ['title' => $title]);
/** @var \App\Models\Listing $listing */
$role = auth()['role'] ?? null;
$hasPin = $listing->shop_latitude !== null && $listing->shop_longitude !== null;
?>
<a class="back-link" href="<?= e(url('/')) ?>">← Back to all food</a>

<div class="detail">
    <div>
        <div class="photo">
            <?= $this->insert('partials/listing-photo', ['listing' => $listing]) ?>
            <?php if ($listing->discount() > 0): ?><span class="badge-off">-<?= $listing->discount() ?>%</span><?php endif ?>
        </div>
        <?php if ($hasPin): ?>
            <div class="panel" style="margin-top:16px">
                <h3>Where to pick it up</h3>
                <p class="muted" style="margin:0"><?= e($listing->shop_address) ?></p>
                <div class="mini-map" id="mini-map"></div>
            </div>
        <?php endif ?>
    </div>

    <div>
        <div class="panel">
            <p class="eyebrow"><?= $listing->icon() ?> <?= e($listing->categoryLabel()) ?></p>
            <h1><?= e($listing->name) ?></h1>
            <p class="muted" style="margin-top:0">from <strong><?= e($listing->shop_name) ?></strong></p>
            <?php if ($listing->description): ?><p><?= e($listing->description) ?></p><?php endif ?>

            <div class="price" style="margin:10px 0"><strong style="font-size:2rem"><?= e(money($listing->price)) ?></strong><s><?= e(money($listing->original_price)) ?></s></div>

            <ul class="facts">
                <li><span class="ic">🕖</span><div><small>Pickup</small>Today, <?= e($listing->pickup_window) ?></div></li>
                <li><span class="ic">📦</span><div><small>Left</small><?= (int) $listing->quantity ?> available</div></li>
                <li><span class="ic">📅</span><div><small>Best before</small><?= e(date('l, M j', strtotime((string) $listing->best_before))) ?></div></li>
                <li><span class="ic">⚠️</span><div><small>Allergens</small><?= e($listing->allergens ?: 'None listed. Ask the shop if unsure.') ?></div></li>
            </ul>
        </div>

        <div class="panel">
            <?php if ($role === 'customer'): ?>
                <h3>Reserve it</h3>
                <p class="muted" style="margin-top:0">You'll get a pickup code. Check the food at the shop, then pay at the counter.</p>
                <form method="post" action="<?= e(route('reservations.store', ['id' => $listing->id])) ?>">
                    <?= csrf_field() ?>
                    <div class="reserve-row">
                        <div class="qty">
                            <label for="quantity" class="sr-only">Quantity</label>
                            <select id="quantity" name="quantity">
                                <?php for ($q = 1; $q <= min(10, (int) $listing->quantity); $q++): ?>
                                    <option value="<?= $q ?>"><?= $q ?> × <?= e(money($listing->price)) ?></option>
                                <?php endfor ?>
                            </select>
                        </div>
                        <button class="button" type="submit">Reserve now</button>
                    </div>
                    <?php if ($err = errors('quantity')): ?><p class="field-error"><?= e($err) ?></p><?php endif ?>
                </form>
            <?php elseif ($role === null): ?>
                <h3>Want this?</h3>
                <p class="muted" style="margin-top:0">Sign in as a customer to reserve it and get a pickup code.</p>
                <a class="button" href="<?= e(route('login')) ?>">Sign in to reserve</a>
                <a class="button ghost" href="<?= e(route('register')) ?>">Create account</a>
            <?php else: ?>
                <h3>Reserving is for customers</h3>
                <p class="muted" style="margin:0">You're signed in as <?= e($role) ?>. Sign in with a customer account to reserve food.</p>
            <?php endif ?>
        </div>
    </div>
</div>

<?php if ($hasPin): ?>
<?php $this->start('scripts') ?>
<?= $this->insert('partials/leaflet') ?>
<script>
    var spot = [<?= (float) $listing->shop_latitude ?>, <?= (float) $listing->shop_longitude ?>];
    var map = L.map('mini-map', { scrollWheelZoom: false }).setView(spot, 16);
    replateTiles(map);
    L.marker(spot, { icon: replatePin(<?= json_encode($listing->icon()) ?>) }).addTo(map)
        .bindPopup(<?= json_encode('<strong>' . e($listing->shop_name) . '</strong>') ?>);
</script>
<?php $this->end() ?>
<?php endif ?>
