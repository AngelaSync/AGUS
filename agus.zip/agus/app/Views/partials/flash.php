<?php if ($msg = flash('success')): ?>
    <div class="alert alert-success" role="status"><?= e($msg) ?></div>
<?php endif ?>
<?php if ($msg = flash('error')): ?>
    <div class="alert alert-error" role="alert"><?= e($msg) ?></div>
<?php endif ?>
