<?php // Leaflet 1.9.4 is bundled in public/assets/vendor so the map works without a CDN. ?>
<link rel="stylesheet" href="<?= e(asset('vendor/leaflet/leaflet.css')) ?>">
<script src="<?= e(asset('vendor/leaflet/leaflet.js')) ?>"></script>
<script>
    // Shared pin style for Replate maps (map tiles © OpenStreetMap contributors).
    window.replatePin = function (emoji) {
        return L.divIcon({ className: '', html: '<div class="map-pin"><span>' + (emoji || '🍽️') + '</span></div>', iconSize: [34, 34], iconAnchor: [17, 34], popupAnchor: [0, -30] });
    };
    window.replateTiles = function (map) {
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);
    };
</script>
