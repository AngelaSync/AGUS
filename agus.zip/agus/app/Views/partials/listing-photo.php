<?php /** @var \App\Models\Listing $listing */ ?>
<?php if ($listing->photo): ?>
    <img src="<?= e(url($listing->photo)) ?>" alt="<?= e($listing->name) ?>" loading="lazy">
<?php else: ?>
    <div class="food-tile <?= e($listing->category) ?>" role="img" aria-label="<?= e($listing->categoryLabel()) ?>"><?= $listing->icon() ?></div>
<?php endif ?>
