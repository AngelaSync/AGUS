<?php /** @var \Agus\View\View $this */ $this->layout('layouts/main', ['title' => $title]);
$labels = ['reserved' => 'Ready for pickup', 'picked_up' => 'Picked up', 'cancelled' => 'Cancelled'];
?>
<div class="page-head">
    <div>
        <h1>My reservations</h1>
        <p class="lead" style="margin:0">Show the code at the counter, check the food, then pay there.</p>
    </div>
    <a class="button" href="<?= e(url('/')) ?>">Find more food</a>
</div>

<?php if (!$reservations): ?>
    <div class="empty">
        <div class="big">🛍️</div>
        <h2>No reservations yet</h2>
        <p class="muted">Find something tasty nearby and reserve it before it's gone.</p>
        <a class="button" href="<?= e(url('/')) ?>">Browse food</a>
    </div>
<?php else: ?>
    <div class="tickets">
        <?php foreach ($reservations as $r): ?>
            <article class="ticket <?= e($r['status']) ?>">
                <div class="top">
                    <span class="badge <?= e($r['status']) ?>"><?= e($labels[$r['status']] ?? $r['status']) ?></span>
                    <span class="muted"><?= e(date('M j, g:i A', strtotime((string) $r['created_at']))) ?></span>
                </div>
                <div class="big-code"><?= e($r['pickup_code']) ?></div>
                <div>
                    <h3 style="margin:0"><?= (int) $r['quantity'] ?> × <?= e($r['listing_name']) ?></h3>
                    <div class="meta"><?= e($r['shop_name']) ?> · <?= e($r['shop_address']) ?></div>
                    <div class="meta">🕖 Pickup <?= e($r['pickup_window']) ?></div>
                </div>
                <div class="row-actions" style="justify-content:space-between">
                    <span class="price"><strong><?= e(money($r['total'])) ?></strong><span class="muted">pay at counter</span></span>
                    <?php if ($r['status'] === 'reserved'): ?>
                        <form method="post" action="<?= e(route('reservations.cancel', ['id' => $r['id']])) ?>" class="inline">
                            <?= csrf_field() ?>
                            <button class="button danger small" type="submit">Cancel</button>
                        </form>
                    <?php endif ?>
                </div>
            </article>
        <?php endforeach ?>
    </div>
<?php endif ?>
