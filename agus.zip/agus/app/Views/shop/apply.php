<?php /** @var \Agus\View\View $this */ $this->layout('layouts/main', ['title' => $title]) ?>

<div class="form-card">
    <p class="eyebrow">For bakeries and carinderias</p>
    <h1>Sell your surplus food</h1>
    <p class="muted">Tell us about your shop. We'll put it on the map, and an admin will verify it before your listings go live.</p>
    <form method="post" action="<?= e(url('/sell')) ?>" novalidate>
        <?= csrf_field() ?>

        <label for="name">Shop name</label>
        <input id="name" name="name" value="<?= e(old('name')) ?>" placeholder="Panaderia ni Aling Rosa" required>
        <?php if ($err = errors('name')): ?><p class="field-error"><?= e($err) ?></p><?php endif ?>

        <label for="address">Address</label>
        <input id="address" name="address" value="<?= e(old('address')) ?>" placeholder="Sto. Rosario St, Angeles City, Pampanga" required>
        <p class="hint">Include the street, city and province so we can find it on the map.</p>
        <?php if ($err = errors('address')): ?><p class="field-error"><?= e($err) ?></p><?php endif ?>

        <button class="button" type="submit">Create my shop</button>
    </form>
</div>
