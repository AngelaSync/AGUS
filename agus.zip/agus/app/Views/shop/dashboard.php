<?php /** @var \Agus\View\View $this */ $this->layout('layouts/main', ['title' => $title]);
/** @var \App\Models\Shop $shop */
$active = array_filter($reservations, fn ($r) => $r['status'] === 'reserved');
$labels = ['reserved' => 'Waiting', 'picked_up' => 'Picked up', 'cancelled' => 'Cancelled'];
?>
<div class="page-head">
    <div>
        <p class="eyebrow">My shop</p>
        <h1><?= e($shop->name) ?></h1>
        <p class="muted" style="margin:0">📍 <?= e($shop->address) ?></p>
    </div>
    <a class="button" href="<?= e(route('shop.listings.create')) ?>">+ Post food</a>
</div>

<?php if ($shop->isVerified()): ?>
    <div class="status-banner ok"><span class="ic">✅</span>Verified. Your listings are live for customers.</div>
<?php else: ?>
    <div class="status-banner pending"><span class="ic">⏳</span>Waiting for an admin to verify your shop. You can post food now; customers will see it once you're verified.</div>
<?php endif ?>

<div class="stat-row">
    <div class="stat-card"><strong><?= count($listings) ?></strong><span>listings</span></div>
    <div class="stat-card"><strong><?= count($active) ?></strong><span>waiting for pickup</span></div>
    <div class="stat-card"><strong><?= array_sum(array_map(fn ($r) => $r['status'] === 'picked_up' ? (int) $r['quantity'] : 0, $reservations)) ?></strong><span>items rescued</span></div>
    <div class="stat-card"><strong><?= $shop->hasPin() ? '📍' : '—' ?></strong><span><?= $shop->hasPin() ? 'on the map' : 'no map pin yet' ?></span></div>
</div>

<section class="section">
    <h2>Pickups</h2>
    <?php if (!$reservations): ?>
        <div class="empty"><div class="big">🧾</div><p class="muted">No reservations yet. They'll appear here with their pickup codes.</p></div>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Code</th><th>Customer</th><th>Food</th><th>Total</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($reservations as $r): ?>
                    <tr>
                        <td><span class="code"><?= e($r['pickup_code']) ?></span></td>
                        <td><?= e($r['customer_name']) ?></td>
                        <td><?= (int) $r['quantity'] ?> × <?= e($r['listing_name']) ?></td>
                        <td><?= e(money($r['total'])) ?></td>
                        <td><span class="badge <?= e($r['status']) ?>"><?= e($labels[$r['status']] ?? $r['status']) ?></span></td>
                        <td>
                            <?php if ($r['status'] === 'reserved'): ?>
                                <form method="post" action="<?= e(route('shop.reservations.pickup', ['id' => $r['id']])) ?>" class="inline">
                                    <?= csrf_field() ?>
                                    <button class="button green small" type="submit">Mark picked up</button>
                                </form>
                            <?php endif ?>
                        </td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
    <?php endif ?>
</section>

<section class="section">
    <h2>My listings</h2>
    <?php if (!$listings): ?>
        <div class="empty"><div class="big">🥐</div><p class="muted">Nothing posted yet.</p><a class="button" href="<?= e(route('shop.listings.create')) ?>">Post your first food</a></div>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Food</th><th>Price</th><th>Left</th><th>Best before</th><th>Pickup</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($listings as $l): $expired = (string) $l->best_before < date('Y-m-d'); ?>
                    <tr>
                        <td>
                            <div class="item-cell">
                                <div class="thumb"><?= $this->insert('partials/listing-photo', ['listing' => $l]) ?></div>
                                <div><strong><?= e($l->name) ?></strong><br><span class="muted"><?= e($l->categoryLabel()) ?></span></div>
                            </div>
                        </td>
                        <td><strong><?= e(money($l->price)) ?></strong> <s class="muted"><?= e(money($l->original_price)) ?></s></td>
                        <td><?= (int) $l->quantity === 0 ? '<span class="badge cancelled">Sold out</span>' : (int) $l->quantity ?></td>
                        <td><?= e(date('M j', strtotime((string) $l->best_before))) ?><?= $expired ? ' <span class="badge cancelled">Expired</span>' : '' ?></td>
                        <td><?= e($l->pickup_window) ?></td>
                        <td>
                            <div class="row-actions">
                                <a class="button ghost small" href="<?= e(route('shop.listings.edit', ['id' => $l->id])) ?>">Edit</a>
                                <form method="post" action="<?= e(route('shop.listings.destroy', ['id' => $l->id])) ?>" class="inline" onsubmit="return confirm('Remove this listing?')">
                                    <?= csrf_field() ?>
                                    <button class="button danger small" type="submit">Remove</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
    <?php endif ?>
</section>
