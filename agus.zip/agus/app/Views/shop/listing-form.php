<?php /** @var \Agus\View\View $this */ $this->layout('layouts/main', ['title' => $title]);
/** @var ?\App\Models\Listing $listing */
$v = fn (string $key, $default = '') => old($key, $listing ? (string) $listing->$key : $default);
$action = $listing ? route('shop.listings.update', ['id' => $listing->id]) : route('shop.listings.store');
$err = function (string $field): string {
    $msg = errors($field);
    return $msg ? '<p class="field-error">' . e($msg) . '</p>' : '';
};
?>
<a class="back-link" href="<?= e(route('shop.home')) ?>">← Back to my shop</a>

<div class="form-card wide">
    <h1><?= $listing ? 'Edit listing' : 'Post surplus food' ?></h1>
    <p class="muted">Customers see this on Replate and pay at your counter when they pick it up.</p>

    <form method="post" action="<?= e($action) ?>" enctype="multipart/form-data" novalidate>
        <?= csrf_field() ?>
        <div class="form-grid">
            <div class="full">
                <label for="name">Food name</label>
                <input id="name" name="name" value="<?= e($v('name')) ?>" placeholder="Pandesal (bag of 10)" required>
                <?= $err('name') ?>
            </div>

            <div>
                <label for="category">Food type</label>
                <select id="category" name="category">
                    <?php foreach (\App\Models\Listing::CATEGORIES as $key => $cat): ?>
                        <option value="<?= e($key) ?>" <?= $v('category', 'bread') === $key ? 'selected' : '' ?>><?= $cat['icon'] ?> <?= e($cat['label']) ?></option>
                    <?php endforeach ?>
                </select>
                <?= $err('category') ?>
            </div>
            <div>
                <label for="quantity">How many are left?</label>
                <input id="quantity" name="quantity" type="number" min="0" max="999" value="<?= e($v('quantity', '5')) ?>" required>
                <?= $err('quantity') ?>
            </div>

            <div>
                <label for="original_price">Original price (₱)</label>
                <input id="original_price" name="original_price" type="number" step="0.01" min="1" value="<?= e($v('original_price')) ?>" required>
                <?= $err('original_price') ?>
            </div>
            <div>
                <label for="price">Replate price (₱)</label>
                <input id="price" name="price" type="number" step="0.01" min="1" value="<?= e($v('price')) ?>" required>
                <?= $err('price') ?>
            </div>

            <div>
                <label for="best_before">Best before</label>
                <input id="best_before" name="best_before" type="date" value="<?= e($v('best_before', date('Y-m-d'))) ?>" required>
                <?= $err('best_before') ?>
            </div>
            <div>
                <label for="pickup_window">Pickup time</label>
                <input id="pickup_window" name="pickup_window" value="<?= e($v('pickup_window', '6:00–8:00 PM')) ?>" required>
                <?= $err('pickup_window') ?>
            </div>

            <div class="full">
                <label for="allergens">Allergens</label>
                <input id="allergens" name="allergens" value="<?= e($v('allergens')) ?>" placeholder="Wheat, egg, milk">
                <?= $err('allergens') ?>
            </div>
            <div class="full">
                <label for="description">Description</label>
                <textarea id="description" name="description" placeholder="Freshly baked this morning. Still soft!"><?= e($v('description')) ?></textarea>
                <?= $err('description') ?>
            </div>
            <div class="full">
                <label for="photo">Photo <?= $listing && $listing->photo ? '(leave empty to keep the current one)' : '' ?></label>
                <input id="photo" name="photo" type="file" accept="image/jpeg,image/png,image/webp">
                <p class="hint">JPG, PNG or WebP, up to 3 MB.</p>
                <?= $err('photo') ?>
            </div>
        </div>
        <button class="button" type="submit"><?= $listing ? 'Save changes' : 'Post food' ?></button>
    </form>
</div>
