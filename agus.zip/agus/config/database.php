<?php
/**
 * Database connection. Pick the driver in .env:
 *   DB_DRIVER=mysql   for XAMPP / MariaDB (the usual choice)
 *   DB_DRIVER=sqlite  for a quick start with no database server
 */

return [
    'driver' => env('DB_DRIVER', 'mysql'),

    'mysql' => [
        'host' => env('DB_HOST', '127.0.0.1'),
        'port' => env('DB_PORT', '3306'),
        'database' => env('DB_DATABASE', 'agus'),
        'username' => env('DB_USERNAME', 'root'),
        'password' => env('DB_PASSWORD', ''),
        'charset' => 'utf8mb4',
    ],

    'sqlite' => [
        'database' => BASE_PATH . '/' . env('DB_SQLITE_PATH', 'storage/database.sqlite'),
    ],
];
